import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import styles from "./Home.module.css";
import Hero from "../components/Hero";
import SecondSection from "../components/SecondSection";

function Home() {
  const sectionRef = useRef(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect(); // 한 번만 실행
        }
      },
      { threshold: 0.2 }, // 20% 보이면 트리거
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div>
      <Hero />
      <SecondSection />
      <section
        ref={sectionRef}
        className={`${styles.overview} ${isVisible ? styles.visible : ""}`}
      >
        <h2 className={styles.overviewTitle}>Overview</h2>

        <p className={styles.overviewText}>
          Project 페이지에는 개인 및 팀 프로젝트에서 진행한 결과물이 담겨
          있습니다. 이 과정에서 고민했던 문제, 해결 방법, 그리고 구현한 기능들을
          통해 저의 기술 스택과 문제 해결 능력을 확인하실 수 있습니다.
          <br />
          About 페이지에서는 저의 경험과 가치관, 그리고 앞으로 개발자로서
          나아가고 싶은 방향을 소개하고 있습니다.
        </p>

        <div className={styles.overviewCards}>
          <Link to="/project" className={styles.overviewCard}>
            <span className={styles.overviewCardTitle}>Project</span>
            <p className={styles.overviewCardDesc}>
              프로젝트 소개, 해결 방법, 관련 공부 기록
            </p>
            <span className={styles.overviewCardArrow}>↗</span>
          </Link>

          <Link to="/about" className={styles.overviewCard}>
            <span className={styles.overviewCardTitle}>About</span>
            <p className={styles.overviewCardDesc}>
              나의 경험과 생각, 프론트엔드 개발자로서의 방향
            </p>
            <span className={styles.overviewCardArrow}>↗</span>
          </Link>
        </div>
      </section>
    </div>
  );
}

export default Home;
